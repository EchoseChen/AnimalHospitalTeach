## [3.0.0] 2022-05-26

- Fix errors
- Update dependencies
- Add new components
- Add new pages and layouts
- Add new design blocks
- Add vuex to the project
- New base strucuture for more reusable components

## [2.0.1] - 2021-09-17

- Fix Inputs v-model

## [2.0.0] - 2021-02-22

### Vue 3 Update

- Compatibility with new Vuejs 3

## [1.1.1] - 2020-11-25

- Change broken links

## [1.1.0] - 2020-06-30

- Package updates

## [1.0.0] - 2019-04-07

### Initial Release
