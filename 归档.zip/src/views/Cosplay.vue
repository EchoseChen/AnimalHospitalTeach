<template>
   <div class="py-4 container sectionHeight" >
    <div class=" row">
        <div class="col-12">
            <cos-card />
        </div>
    </div>
    </div>
</template>
<script>
import CosCard from "./components/CosCard.vue";
export default{
    name:"Cosplay",
    components:{
        CosCard
    },
    
};
</script>


